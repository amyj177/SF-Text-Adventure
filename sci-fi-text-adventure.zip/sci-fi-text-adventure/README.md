# Sci-Fi Text Adventure

A Pen created on CodePen.io. Original URL: [https://codepen.io/amyj177/pen/zYmRBxW](https://codepen.io/amyj177/pen/zYmRBxW).

